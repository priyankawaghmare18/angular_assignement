import { Component, OnInit, ViewChild } from '@angular/core';
import { DashboardService } from '../dashboard.service';
import { MatTableDataSource, MatPaginator } from '@angular/material';

export interface PeriodicElement {
  name: string;
  date: string;
  status: number;
  type: string;
  time : string;
  amount :string;
  action :string;

}
const ELEMENT_DATA: PeriodicElement[] = [
  { date: '01/01/2023', name: 'Abc', status: 1.0079, type: 'Transfer' , time:'',amount:'$550.00',action:':'},
  { date: '01/01/2023', name: 'Pqr', status: 1.0079, type: 'Card transfer' , time:'',amount:'$550.00',action:':'},
  { date: '01/01/2023', name: 'Lmn', status: 1.0079, type: 'T' , time:'',amount:'$550.00',action:':' },
  { date: '01/01/2023', name: 'Ijk', status: 1.0079, type: 'C T' , time:'',amount:'$550.00',action: ':'},
  { date: '01/01/2023', name: 'Klm', status: 1.0079, type: 'T' , time:'',amount:'$550.00',action: ':'},
  { date: '01/01/2023', name: 'Uvw', status: 1.0079, type: 'T' , time:'',amount:'$550.00',action: ':'},
  { date: '01/01/2023', name: 'Abc11', status: 1.0079, type: 'C T' , time:'',amount:'$550.00',action: ':'},
  { date: '01/01/2023', name: 'Pqr11', status: 1.0079, type: 'T' , time:'',amount:'$550.00',action:':' },
  { date: '01/01/2023', name: 'Lmn11', status: 1.0079, type: 'C T' , time:'',amount:'$550.00',action:':' },
  { date: '01/01/2023', name: 'Ijk11', status: 1.0079, type: 'C T' , time:'',amount:'$550.00',action:':' },
  
];

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  bigChart = [];
  cards = [];
  pieChart = [];

  displayedColumns: string[] = ['date', 'name', 'status', 'type','time','amount','action'];
  dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;

  constructor(private dashboardService: DashboardService) { }

  ngOnInit() {
    this.bigChart = this.dashboardService.bigChart();
    this.cards = this.dashboardService.cards();
   

    this.dataSource.paginator = this.paginator;
  }

}
